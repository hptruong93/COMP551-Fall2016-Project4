This annotated animal movement dataset comes from the Env-DATA Track Annotation Service on Movebank (movebank.org). The environmental data attributes are created and distributed by government and research organizations. For general information on the Env-DATA System, see Dodge et al. (2013) and https://www.movebank.org/node/6607.

Terms of Use: Verify the terms of use for relevant tracking data and environmental datasets prior to presenting or publishing these data. Terms of use for animal movement data in Movebank are defined by the study owners in the License Terms for the study. Terms of use for environmental datasets vary by provider; see below for details.

Contact: support@movebank.org

---------------------------

Annotated data for the following Movebank entities are contained in this file:
Movebank study name: Common Eider Petersen Alaska 2000-2009
Annotated Animal IDs: 1347-82156, 1347-27401, 1347-27402, 1347-76451, 1347-76452, 1347-76453, 1347-76454, 1347-76455, 1347-76456, 1347-76457, 1347-76458, 1347-76459, 1347-76460, 1347-76461, 1347-76462, 1347-76463, 1347-76464, 1347-76465, 1347-76466, 1347-76467, 1347-76468, 1347-76469, 1347-76470, 1347-76471, 1347-76472, 1347-76473, 1347-76474, 1347-76475, 1347-76476, 1347-76477, 1347-76478, and more ...
Requested on Sat Nov 26 14:10:44 CET 2016
Access key: 4123589911317611188
Requested by: Yue Xia

---------------------------

File attributes

Attributes from the Movebank database (see the Movebank Attribute Dictionary at http://www.movebank.org/node/2381):
Location Lat: latitude in decimal degrees, WGS84 reference system
Location Long: longitude in decimal degrees, WGS84 reference system
Timestamp: the time of the animal location estimates, in UTC
Argos Lat1
Argos Lon1
Argos Lat2
Argos Lon2
Argos Nb Mes
Argos Nb Mes 120
Argos Best Level
Argos Pass Duration
Argos NOPC
Argos Altitude
Argos Sensor 1
Argos Sensor 2
Argos Sensor 3
Argos Sensor 4
Argos LC
Argos IQ
Argos Calcul Freq
Algorithm Marked Outlier
Manually Marked Outlier
Argos Valid Location Manual
Manually Marked Valid

Locations are the the geographic coordinates of locations along an animal track as estimated by the processed sensor data.

Attributes from annotated environmental data:
Name: MODIS Land Aqua Surface Temp & Emissivity 1km Daily Daytime Clear Sky Coverage
Unit: none
No data values: 0 (provider), NaN (interpolated)
Interpolation: bilinear

Name: MODIS Land Aqua Surface Temp & Emissivity 1km Daily Land Surface Temperature Daytime
Description: Daytime land surface temperature
Unit: Kelvin
No data values: 0 (provider), NaN (interpolated)
Interpolation: bilinear

Name: NCEP NARR SFC Soil Moisture Parameter In Canopy Conductance at Surface
Unit: unitless (fraction)
No data values: NaN (interpolated)
Interpolation: bilinear

Name: NCEP NARR SFC Humidity Parameter in Canopy Conductance at Surface
Unit: (0-1)
No data values: NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC Snow Temperature
Description: The temperature of the snow, if snow is present.
Unit: K
No data values: NaN (interpolated)
Interpolation: bilinear

Name: NASA Distance to Coast (Signed)
Description: The distance to the nearest ocean coastline. Inland distances are given as negative numbers. Note: Incorrected coastline is found in some fjords of southern Chile and northern Greenland. 1 km uncertainty may lead to 2 km distance being adjacent to the coastline.
Unit: km
No data values: NaN (provider), NaN (interpolated)
Interpolation: bilinear

Name: GlobCover 2009 2009 Land-Cover Classification
Unit: none
No data values: 255 (provider), NaN (interpolated)
Interpolation: nearest-neighbour

Name: MODIS Land Aqua Surface Temp & Emissivity 1km Daily Nighttime Clear Sky Coverage
Unit: none
No data values: 0 (provider), NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC-FC Runoff
Description: Amount of water that is lost from the soil through surface runoff and deep soil drainage.
Unit: m
No data values: NaN (interpolated)
Interpolation: bilinear

Name: MODIS Land Aqua Surface Temp & Emissivity 1km Daily Land Surface Temperature Nighttime
Description: Nighttime land surface temperature
Unit: Kelvin
No data values: 0 (provider), NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC Ice Temperature at 0-7 cm
Description: Temperature of the sea ice top layer (0-7 cm)
Unit: K
No data values: NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC Soil Temperature at 1-7 cm
Description: Temperature of the top soil layer (1-7 cm). Same as soil temperature (ST) before 19930804.
Unit: K
No data values: NaN (interpolated)
Interpolation: bilinear

Name: NCEP NARR SFC Snow Cover at Surface
Unit: unitless (fraction)
No data values: NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC Volumetric Soil Water Content at 1-7 cm
Description: The fraction of soil volume that is water in the top soil layer (1-7 cm)
Unit: unitless (m^3 m^-3)
No data values: NaN (interpolated)
Interpolation: bilinear

---------------------------

Environmental data services

Service: MODIS Land/Aqua Land Surface Temperature & Emissivity 1-km Daily (MYD11A1 V041)
Provider: NASA Land Processes Distributed Active Archive Center
Datum: N/A
Projection: N/A
Spatial granularity: 1 km
Spatial range (long x lat): E: 180.0    W: -180.0 x N: 90    S: -90
Temporal granularity: daily
Temporal range: since January 2007
Source link: https://lpdaac.usgs.gov/products/modis_products_table/MYD11a1
Terms of use: https://lpdaac.usgs.gov/about/citing_lp_daac_and_data

Service: NCEP North American Regional Reanalysis (NARR)/Surface
Provider: Research Data Archive at the National Center for Atmospheric Research, Computational and Information Systems Laboratory
Datum: N/A
Projection: N/A
Spatial granularity: 0.3 degrees
Spatial range (long x lat): W: -49.4    W: -152.9 x N: 57.3    N: 12.2
Temporal granularity: 3 hourly
Temporal range: 1979-01-01 to previous year
Source link: http://rda.ucar.edu/datasets/ds608.0/index.html#sfol-wl-/data/ds608.0?g=3
Terms of use: http://rda.ucar.edu/datasets/ds608.0/

Service: ECMWF Global Atmospheric Reanalysis/Interim Full Daily at Surface
Provider: European Centre for Medium-Range Weather Forecasts
Datum: N/A
Projection: N/A
Spatial granularity: 0.75 degrees
Spatial range (long x lat): E: 180.0    W: -180.0 x N: 89.463    S: -89.463
Temporal granularity: 6 hourly
Temporal range: 1979-01-01 to present
Source link: http://apps.ecmwf.int/datasets/data/interim_full_daily/?levtype=sfc
Terms of use: http://data-portal.ecmwf.int/data/d/license/interim_full/

Service: ECMWF Global Atmospheric Reanalysis/Interim Full Daily at Surface Forecast
Provider: European Centre for Medium-Range Weather Forecasts
Datum: N/A
Projection: N/A
Spatial granularity: 0.75 degrees
Spatial range (long x lat): E: 180.0    W: -180.0 x N: 89.463    S: -89.463
Temporal granularity: 3 hourly
Temporal range: 1979-01-01 to present
Source link: http://apps.ecmwf.int/datasets/data/interim_full_daily/?levtype=sfc
Terms of use: http://data-portal.ecmwf.int/data/d/license/interim_full/

Service: GlobCover/Land Cover 2009
Provider: European Space Agency
Datum: N/A
Projection: N/A
Spatial granularity: 300 m
Spatial range (long x lat): E: 180.0    W: -180.0 x N: 90    S: -65
Temporal granularity: 8 day
Temporal range: 2009
Source link: http://dup.esrin.esa.it/page_globcover.php
Terms of use: http://due.esrin.esa.int/globcover/LandCover2009/GLOBCOVER2009_Validation_Report_2.2.pdf

Service: NASA Distance to the Nearest Coast
Provider: NASA Ocean Biology Processing Group
Datum: N/A
Projection: N/A
Spatial granularity: 0.04 degrees
Spatial range (long x lat): E: 180.0    W: -180.0 x N: 90    S: -90
Temporal granularity: N/A
Temporal range: N/A
Source link: http://oceancolor.gsfc.nasa.gov/DOCS/DistFromCoast/
Terms of use: none found

Dodge, S., Bohrer, G., Weinzierl, R., Davidson, S.C., Kays, R., Douglas, D., Cruz, S., Han, J., Brandes, D., and Wikelski, M., 2013, The Environmental-Data Automated Track Annotation (Env-DATA) System: Linking animal tracks with environmental data: Movement Ecology, v. 1:3. doi:10.1186/2051-3933-1-3.