This annotated animal movement dataset comes from the Env-DATA Track Annotation Service on Movebank (movebank.org). The environmental data attributes are created and distributed by government and research organizations. For general information on the Env-DATA System, see Dodge et al. (2013) and https://www.movebank.org/node/6607.

Terms of Use: Verify the terms of use for relevant tracking data and environmental datasets prior to presenting or publishing these data. Terms of use for animal movement data in Movebank are defined by the study owners in the License Terms for the study. Terms of use for environmental datasets vary by provider; see below for details.

Contact: support@movebank.org

---------------------------

Annotated data for the following Movebank entities are contained in this file:
Movebank study name: Common Eider Petersen Alaska 2000-2009
Annotated Animal IDs: 1347-82156, 1347-27401, 1347-27402, 1347-76451, 1347-76452, 1347-76453, 1347-76454, 1347-76455, 1347-76456, 1347-76457, 1347-76458, 1347-76459, 1347-76460, 1347-76461, 1347-76462, 1347-76463, 1347-76464, 1347-76465, 1347-76466, 1347-76467, 1347-76468, 1347-76469, 1347-76470, 1347-76471, 1347-76472, 1347-76473, 1347-76474, 1347-76475, 1347-76476, 1347-76477, 1347-76478, and more ...
Requested on Sun Nov 27 02:15:26 CET 2016
Access key: 9077086894189101928
Requested by: Yue Xia

---------------------------

File attributes

Attributes from the Movebank database (see the Movebank Attribute Dictionary at http://www.movebank.org/node/2381):
Location Lat: latitude in decimal degrees, WGS84 reference system
Location Long: longitude in decimal degrees, WGS84 reference system
Timestamp: the time of the animal location estimates, in UTC
Argos Lat1
Argos Lon1
Argos Lat2
Argos Lon2
Argos Nb Mes
Argos Nb Mes 120
Argos Best Level
Argos Pass Duration
Argos NOPC
Argos Altitude
Argos Sensor 1
Argos Sensor 2
Argos Sensor 3
Argos Sensor 4
Argos LC
Argos IQ
Argos Calcul Freq
Algorithm Marked Outlier
Manually Marked Outlier
Argos Valid Location Manual
Manually Marked Valid

Locations are the the geographic coordinates of locations along an animal track as estimated by the processed sensor data.

Attributes from annotated environmental data:
Name: ECMWF Interim Full Daily SFC-FC Evaporation
Description: Evaporation from the surface into the atmosphere. Downward fluxes are positive.
Unit: m of water equivalent
No data values: NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC Temperature (2 m above Ground)
Description: Air temperature 2 m above the ground or water surface
Unit: K
No data values: NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC-FC Sunshine Duration
Description: Accumulated time that radiation in the direction of the sun is greater than 120 W/(m^2).
Unit: s
No data values: NaN (interpolated)
Interpolation: bilinear

Name: NCEP NARR SFC Visibility at Surface
Unit: m
No data values: NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC Charnock Parameter
Description: A value used to characterize the surface roughness length over the ocean surface when winds are strong. This is used to model turbulent wind and other climate conditions over the ocean.
Unit: unitless
No data values: NaN (interpolated)
Interpolation: bilinear

Name: NCEP NARR 3D Cloud Water
Description: The concentration of ice and liquid water in clouds.
Unit: unitless (kg/kg)
No data values: NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC Sea Ice Cover
Description: Fraction of model grid box that is covered with sea ice.
Unit: (0-1)
No data values: NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily PL V Velocity
Description: Velocity of the north-south (meridoinal) component of wind
Unit: m/s
No data values: NaN (interpolated)
Interpolation: bilinear
Z-Dimension: 1000.0

Name: ECMWF Interim Full Daily PL U Velocity
Description: Velocity of the east-west (zonal) component of wind
Unit: m/s
No data values: NaN (interpolated)
Interpolation: bilinear
Z-Dimension: 1000.0

Name: ECMWF Interim Full Daily SFC Total Cloud Cover
Description: The cloud cover for the total atmospheric column (all model levels).
Unit: (0-1)
No data values: NaN (interpolated)
Interpolation: bilinear

Name: SEDAC GRUMP v1 2000 Population Density Adjusted
Description: Human population densities in 2000, adjusted to match totals in the UN's 1999 "World Population Prospects: The 1998 Revision. Volume 1: Comprehensive Tables"
Unit: persons/km^2
No data values: NaN (provider), NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC Surface Air Pressure
Description: Atmospheric pressure (pressure caused by the weight of the atmosphere) at the earth's surface.
Unit: Pa
No data values: NaN (interpolated)
Interpolation: bilinear

Name: ECMWF Interim Full Daily SFC Total Atmospheric Water
Description: Total water in the entire atmospheric column (water vapor + cloud water + cloud ice)
Unit: kg m^-2
No data values: NaN (interpolated)
Interpolation: bilinear

---------------------------

Environmental data services

Service: NASA Socioeconomic Data and Applications Center (SEDAC)/Global Rural-Urban Mapping Project (GRUMP) v1
Provider: CIESIN at Columbia University
Datum: N/A
Projection: N/A
Spatial granularity: 30 arc-second
Spatial range (long x lat): E: 180.0    W: -180.0 x N: 85    S: - 58
Temporal granularity: 5 yearly
Temporal range: 1990 – 2000
Source link: http://sedac.ciesin.columbia.edu/gpw/
Terms of use: http://sedac.ciesin.columbia.edu/citations

Service: NCEP North American Regional Reanalysis (NARR)/3D
Provider: Research Data Archive at the National Center for Atmospheric Research, Computational and Information Systems Laboratory
Datum: N/A
Projection: N/A
Spatial granularity: 0.3 degrees
Spatial range (long x lat): W: -49.4    W: -152.9 x N: 57.3    N: 12.2
Temporal granularity: 3 hourly
Temporal range: 1979-01-01 to previous year
Source link: http://rda.ucar.edu/datasets/ds608.0/index.html#sfol-wl-/data/ds608.0?g=3
Terms of use: http://rda.ucar.edu/datasets/ds608.0/

Service: ECMWF Global Atmospheric Reanalysis/Interim Full Daily at Pressure Levels
Provider: European Centre for Medium-Range Weather Forecasts
Datum: N/A
Projection: N/A
Spatial granularity: 0.75 degrees
Spatial range (long x lat): E: 180.0    W: -180.0 x N: 89.463    S: -89.463
Temporal granularity: 6 hourly
Temporal range: 1979-01-01 to present
Source link: http://apps.ecmwf.int/datasets/data/interim_full_daily/?levtype=pl
Terms of use: http://data-portal.ecmwf.int/data/d/license/interim_full/

Service: NCEP North American Regional Reanalysis (NARR)/Surface
Provider: Research Data Archive at the National Center for Atmospheric Research, Computational and Information Systems Laboratory
Datum: N/A
Projection: N/A
Spatial granularity: 0.3 degrees
Spatial range (long x lat): W: -49.4    W: -152.9 x N: 57.3    N: 12.2
Temporal granularity: 3 hourly
Temporal range: 1979-01-01 to previous year
Source link: http://rda.ucar.edu/datasets/ds608.0/index.html#sfol-wl-/data/ds608.0?g=3
Terms of use: http://rda.ucar.edu/datasets/ds608.0/

Service: ECMWF Global Atmospheric Reanalysis/Interim Full Daily at Surface
Provider: European Centre for Medium-Range Weather Forecasts
Datum: N/A
Projection: N/A
Spatial granularity: 0.75 degrees
Spatial range (long x lat): E: 180.0    W: -180.0 x N: 89.463    S: -89.463
Temporal granularity: 6 hourly
Temporal range: 1979-01-01 to present
Source link: http://apps.ecmwf.int/datasets/data/interim_full_daily/?levtype=sfc
Terms of use: http://data-portal.ecmwf.int/data/d/license/interim_full/

Service: ECMWF Global Atmospheric Reanalysis/Interim Full Daily at Surface Forecast
Provider: European Centre for Medium-Range Weather Forecasts
Datum: N/A
Projection: N/A
Spatial granularity: 0.75 degrees
Spatial range (long x lat): E: 180.0    W: -180.0 x N: 89.463    S: -89.463
Temporal granularity: 3 hourly
Temporal range: 1979-01-01 to present
Source link: http://apps.ecmwf.int/datasets/data/interim_full_daily/?levtype=sfc
Terms of use: http://data-portal.ecmwf.int/data/d/license/interim_full/

Dodge, S., Bohrer, G., Weinzierl, R., Davidson, S.C., Kays, R., Douglas, D., Cruz, S., Han, J., Brandes, D., and Wikelski, M., 2013, The Environmental-Data Automated Track Annotation (Env-DATA) System: Linking animal tracks with environmental data: Movement Ecology, v. 1:3. doi:10.1186/2051-3933-1-3.